close all

% -------------------------------------
figure(2)
set(gcf,'Position',[100 100 1200 800]) % [x0 y0 width height]

% グラフの配置 [left bottom width height]
position1 = [0.1 0.63  0.85 0.35];  % y
position2 = [0.1 0.45  0.85 0.14];  % y - ym
position3 = [0.1 0.275 0.85 0.14];  % u
position4 = [0.1 0.075 0.85 0.16];  % d_hat

% ***************
subplot('Position',position1) 

plot([0 1 1 4 4 7 7 10],ref*[0 0 1 1 2 2 3 3],'k')
hold on
p2 = plot(t,rad2deg(ym),'LineWidth',1.5,'Color','#00B0F0');
p1 = plot(t,rad2deg(y), 'LineWidth',1.5,'Color','#E84746');
hold off

set(gca,'fontname','arial','FontSize',16)
ylabel('$y$ and ${y}_{\rm m}$ [deg]', 'interpreter','latex','FontSize',18)

ylim([-20 230])
set(gca,'YTick',0:30:300)
xlim([0 10])
set(gca,'XTick',0:1:10)
set(gca,'XTickLabel',{''})
grid on

legend([p1 p2],...
       {'\hskip2pt $y\quad$',
        '\hskip2pt ${y}_{\rm m}\hskip2pt$'}, ...
        'interpreter','latex','FontSize',16,...
        'Location','NorthWest','NumColumns',2)

% ***************
subplot('Position',position3) % [left bottom width height]

plot(t,u,'LineWidth',1.5,'Color','#E84746')

set(gca,'fontname','arial','FontSize',16)
ylabel('$u$ [V]', 'interpreter','latex','FontSize',18)

ylim([-2 4])
set(gca,'YTick',-2:2:4)
xlim([0 10])
set(gca,'XTickLabel',{''})
grid on

% ***************
subplot('Position',position2) % [left bottom width height]

plot(t, rad2deg(y-ym), 'LineWidth',1.5,'Color','#E84746');

set(gca,'fontname','arial','FontSize',16)
ylabel('$y - {y}_{\rm m}$ [deg]', 'interpreter','latex','FontSize',18)

ylim([-6 6])
set(gca,'YTick',-6:3:6)
set(gca,'XTick',0:1:10)
set(gca,'XTickLabel',{''})
grid on

% ***************
subplot('Position',position4) % [left bottom width height]

p3 = plot(t,d_hat,'LineWidth',1.5,'Color','#00B0F0');
hold on
p4 = plot(t, gamma*(y-sin(y)) - d_fri, 'LineWidth',1.5,'Color','#E84746');
hold off

set(gca,'fontname','arial','FontSize',16)
xlabel('$t$ [s]', 'interpreter', 'latex','FontSize',18)
ylabel('$d$ and $\widehat{d}$ [V]', 'interpreter', 'latex','FontSize',18)

ylim([-2 4])
set(gca,'YTick',-10:2:10)
xlim([0 10])
grid on

legend([p4 p3],...
       {'\hskip2pt $d = \gamma(y - \sin{y}) - d_{\rm fri}\quad$',
        '\hskip2pt $\widehat{d}\hskip2pt$'}, ...
        'interpreter','latex','FontSize',16,...
        'Location','NorthWest','NumColumns',2)
