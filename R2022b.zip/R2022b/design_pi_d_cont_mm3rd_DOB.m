clear
format compact

ref = 60;

% ===================================================
% アーム系のパラメータ
% ===================================================
alpha = 1.1666e-02;
beta  = 2.4771e-01;
gamma = 8.5001e-01;

b  =     1/alpha;
a1 =  beta/alpha;
a0 = gamma/alpha;

% -----------------------------------------
ds = 0.5;   % 最大静止摩擦
dk = 0.25;  % 動摩擦

eps = 0.005;    % Karnopp 摩擦モデル

% ===================================================
% 部分的モデルマッチング法による PI-D コントローラ設計
% ===================================================
wm = 15;

% Butterworth
am2 = 2;
am1 = 2;

% binomial
% am2 = 3;
% am1 = 3;

% ITAE
% am2 = 1.75;
% am1 = 2.15;

% -----------------------------------------
gamma1 = am1/wm;
gamma2 = am2/wm^2;
gamma3 =   1/wm^3;

% -----------------------------------------
kI = a0/(b*gamma1);
kP = (1/b - gamma3*kI)/gamma2;
kD = gamma2*kI + (1/b)*(a0*kP/kI - a1);

fprintf('~~~~~~~~~~~~~~~~~~~~~~~~~ \n')
fprintf('部分的モデルマッチング法 \n')
fprintf('wm  = %5.4e\n',wm)
fprintf('am2 = %5.4e\n',am2)
fprintf('am1 = %5.4e\n',am1)
fprintf('~~~~~~~~~~~~~~~~~~~~~~~~~ \n')
fprintf('kI = %5.4e\n',kI)
fprintf('kP = %5.4e\n',kP)
fprintf('kD = %5.4e\n',kD)

% ===================================================
% 外乱オブザーバによる設計
% ===================================================
wc = 250;   % 2 次のバターワースフィルタ

fprintf('========================= \n')
fprintf('2次のバターワースフィルタ \n')
fprintf('wc  = %5.4e\n',wc)
fprintf('~~~~~~~~~~~~~~~~~~~~~~~~~ \n')

s = tf('s');
sysGf = wc^2/(s^2 + sqrt(2)*wc*s + wc^2)

fprintf('~~~~~~~~~~~~~~~~~~~~~~~~~ \n')
fprintf('ノミナルモデル Pn \n')
sysPn = b/(s^2 + a1*s + a0)
sysGf_invPn = sysGf/sysPn;
sysGf_invPn = tf(zpk(sysGf_invPn));

% -----------------------------------------
Tf2 =  1/(sqrt(2)*wc);
kI2 = wc/(sqrt(2)*b)*a0;
kP2 = wc/(sqrt(2)*b)*(a1 - a0/(sqrt(2)*b));
kD2 = wc/(sqrt(2)*b)*(1 - 1/(sqrt(2)*b)*(a1 - a0/(sqrt(2)*b)));

fprintf('========================= \n')
fprintf('外乱オブザーバによる誤差補償器 \n')
fprintf('wc  = %5.4e\n',wc)
fprintf('~~~~~~~~~~~~~~~~~~~~~~~~~ \n')
fprintf('Tf2 = %5.4e\n',Tf2)
fprintf('kI2 = %5.4e\n',kI2)
fprintf('kP2 = %5.4e\n',kP2)
fprintf('kD2 = %5.4e\n',kD2)
fprintf('========================= \n')



